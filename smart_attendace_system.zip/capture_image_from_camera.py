import cv2

cam_port = 0
cam = cv2.VideoCapture(cam_port)

# Reading the input using the camera
inp = input('Enter person name: ')

# Create a constant window name
window_name = 'Capture_Window'

while True:
    # Capture frame-by-frame
    ret, frame = cam.read()

    # Display the resulting frame
    cv2.imshow(window_name, frame)

    # Wait for a key event and check if it's the key 's' (ASCII value 115)
    key = cv2.waitKey(1)
    if key == ord('s'):
        # Save the image with the given person's name
        cv2.imwrite(inp + ".png", frame)
        print("Image taken")
        break
    elif key == 27:  # Check if the 'Esc' key is pressed (ASCII value 27)
        print("Capture aborted")
        break

# Release the camera and close the window
cam.release()
cv2.destroyAllWindows()

